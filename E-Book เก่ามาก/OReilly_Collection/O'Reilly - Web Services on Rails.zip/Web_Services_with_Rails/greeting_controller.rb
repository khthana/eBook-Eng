class GreetingController < ApplicationController
  def dogreeting(username)
    "Hello #{username}"
  end
end
