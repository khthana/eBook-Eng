class GreetingApi < ActionWebService::API::Base
  api_method :dogreeting, 
    :expects => [{:username => :string}], 
    :returns => [{:greeting => :string}]
end
