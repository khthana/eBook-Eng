class CodeController < ApplicationController
  layout "application", :except => [:restserver, :index]
  
  def googletest
    yourkey = '**REPLACE WITH YOUR KEY**'
    @yourquery = @params["searchtext"] || "Ruby"
    XSD::Charset.encoding = 'UTF8'

    driver = SOAP::RPC::Driver.new("http://api.google.com/search/beta2","urn:GoogleSearch")
    driver.add_method('doGoogleSearch', 'key', 'q', 'start', 'maxResults', 'filter', 'restrict', 'safeSearch', 'lr', 'ie', 'oe')
    @result = driver.doGoogleSearch(yourkey, @yourquery, 0, 3, false, '', false, '', '', '')
  end

  def googlewsdltest
    yourkey = '**REPLACE WITH YOUR KEY**'
    @yourquery = @params["searchtext"] || "Ruby WSDL"
    XSD::Charset.encoding = 'UTF8'

    driver = SOAP::WSDLDriverFactory.new("http://api.google.com/GoogleSearch.wsdl").create_rpc_driver
    @result = driver.doGoogleSearch(yourkey,@yourquery,0,3,false,'',false,'','','')
  end

  def yahootest
    @yourquery = @params["searchtext"] || "Ruby"
    query = CGI.escape(@yourquery)
    yahookey = "**REPLACE WITH YOUR KEY**"
    newurl = "http://api.search.yahoo.com/WebSearchService/V1/webSearch?appid=#{yahookey}&query=#{query}&results=3&start=1"
    @doc = REXML::Document.new Net::HTTP.get(URI(newurl))
  end

  def flickrtest
    server = XMLRPC::Client.new2("http://www.flickr.com/services/xmlrpc/")
    flickrkey = "**REPLACE WITH YOUR KEY**"
    details = {:api_key => flickrkey, :per_page => "3"}
    @doc = REXML::Document.new server.call("flickr.interestingness.getList", details)
  end

  def restserver
    # sample rest service
    @sampledata = ["Kevin","Timothy","Catherine"]
  end
    
  def alexatest
    # this example requires that you have hmac-sha1 installed and included in your environment.rb file
    url = "draftwizard.com"
    responsegroup = "Rank"
    temp = Time.now.utc
    t1 = temp.strftime("%Y-%m-%dT%H:%M:%SZ")
    newtime = t1.to_s
    encval = "AlexaWebInfoServiceUrlInfo" + t1.to_s
    myhmac = HMAC::SHA1.digest("**REPLACE WITH YOUR KEY**", encval)
    myhmac = myhmac.to_a.pack("m").chomp
    driver = SOAP::RPC::Driver.new("http://awis.amazonaws.com/onca/soap?Service=AlexaWebInfoService","http://webservices.amazon.com/AWSAlexa/2005-07-11")
    driver.add_rpc_method_with_soapaction_as("test", "UrlInfo", "UrlInfo", "AWSAccessKeyId", "Signature", "Timestamp", "Url", "ResponseGroup")
    @result = driver.test("069K24V0MT7DQGW8CNG2", myhmac, newtime, url, responsegroup)
  end
end
