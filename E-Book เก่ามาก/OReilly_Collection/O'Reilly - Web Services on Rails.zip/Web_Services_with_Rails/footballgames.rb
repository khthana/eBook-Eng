class Footballgames < ActiveRecord::Base
  set_primary_key "GameTimeStats_ID"
  set_table_name "GameTimeStats"
end
