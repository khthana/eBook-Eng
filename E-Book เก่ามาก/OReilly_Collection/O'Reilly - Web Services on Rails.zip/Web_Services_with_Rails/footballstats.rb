class Footballstats < ActionWebService::Struct
    # our football stats struct model
    member :statfor, :string
    member :stattype, :string
	member :statvalue, :string
	member :statlogged, :datetime
	member :statnote, :string
end

