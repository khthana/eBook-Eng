class Getstats < ActionWebService::Base
  web_service_api StatsApi
  before_invocation :checkusername, :except => [:listgames]

  def getgamestats(username, gamename)
    # get the stats for a specific game
    stats = [
	  Footballstats.new(:statfor => 'Brett Favre', :stattype => 'Passing yards', :statvalue => '255', :statlogged => '9/23/2001'),
	  Footballstats.new(:statfor => 'Jevon Walker', :stattype => 'Receiving yards', :statvalue => '104', :statlogged => '9/23/2001')
	]
  end

  def listgames(year)
    # get a list of football games stats are available for
	Footballgames.find_by_sql(["select distinct gamename from gametimestats where gametimestats_year = ?", year]).map {|rec| rec.gamename}
  end

protected
  def checkusername(name, args)
    # very generic/non-secure example
	if (args[0] != "kevin")
	  raise "Access denied!"
    end
  end
end
