class StatsController < ApplicationController
  web_service_dispatching_mode :layered
#  web_service_dispatching_mode :delegated

  wsdl_service_name 'Stats'
  wsdl_namespace 'urn:sportsxml'

  web_service :footballstats, Getstats.new

  web_service_scaffold :test

  def about
      # information about our service
	  # accessed through reg. web browser
	  # http://localhost:3000/stats/about
  end
end
