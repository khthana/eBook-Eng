class StatsApi < ActionWebService::API::Base
  api_method :getgamestats, 
    :expects => [{:username => :string}, {:gamename => :string}],
    :returns => [[Footballstats]]

  api_method :listgames, 
    :expects => [{:year => :int}],
    :returns => [[:string]]
end
