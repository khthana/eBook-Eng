RAILS_GEM_VERSION = '1.1.2'

require File.join(File.dirname(__FILE__), 'boot')

Rails::Initializer.run do |config|
end

require 'labeling_form_helper'