class Project < Post
end