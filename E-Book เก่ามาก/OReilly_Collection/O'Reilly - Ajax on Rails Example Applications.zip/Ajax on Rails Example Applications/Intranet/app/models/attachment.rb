class Attachment < ActiveRecord::Base
end
