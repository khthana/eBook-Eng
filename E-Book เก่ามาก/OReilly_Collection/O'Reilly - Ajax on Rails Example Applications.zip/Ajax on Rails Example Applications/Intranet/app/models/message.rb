class Message < Post
end