class Document < Post
end
