class ProjectsController < PostsController

  private
    def model_name; 'Project'; end

end
