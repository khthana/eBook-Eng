class DocumentsController < PostsController

  private
    def model_name; 'Document'; end

end
