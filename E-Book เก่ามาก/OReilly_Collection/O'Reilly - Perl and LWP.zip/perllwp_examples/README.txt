
Example code from /Perl and LWP/ by Sean M. Burke
ISBN 0-596-00178-9
http://www.oreilly.com/catalog/perllwp/

Report any errors or omissions to sburke@cpan.org

Programs in this archive are distributed only in the hope that they it
will be usefully illustrative of points in the book, but without any
warranty; without even the implied warranty of merchantability or
fitness for a particular purpose.

__END__

