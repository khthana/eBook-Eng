#!/usr/bin/perl

# Example code from Chapter 6 of /Perl and LWP/ by Sean M. Burke
# http://www.oreilly.com/catalog/perllwp/
# sburke@cpan.org

# NOTE: this program no longer works, because O'Reilly
#  changed their template.

require 5;
use strict;
use warnings;

use LWP::Simple;
use Text::Wrap;

my $html = get("http://www.oreillynet.com/")
 or die "Couldn't access!";

while ($html =~ m{<!-- itemtemplate -->(.*?)</p>}gs) {
  my$chunk = $1;
  my($URL, $title, $summary) =
     $chunk =~ m{href="(.*?)">(.*?)</a></b>\s*&nbsp;\s*(.*?)\[}i
     or next;
  $summary =~ s{&nbsp;}{ }g;
  $summary =~ s{<.*?>}{}sg;
  print "$URL\n$title\n", wrap("  ", "  ", $summary), "\n\n";
}
__END__

