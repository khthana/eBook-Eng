#!/usr/bin/perl

# Example code from Chapter 6 of /Perl and LWP/ by Sean M. Burke
# http://www.oreilly.com/catalog/perllwp/
# sburke@cpan.org

# NOTE: stopped working, because amazon changed their output format.

require 5;
use strict;
use warnings;

# amazon-rank: fetch amazon rank given ISBN on cmdline

use LWP::Simple;

my $isbn = shift
  or die "usage:\n$0 ISBN\n";
my $html = get("http://www.amazon.com/exec/obidos/ASIN/$isbn");
$html =~ m{Amazon\.com Sales Rank: </b> ([\d,]+) </font><br>}
  or die "Couldn't find the sales rank in the page";
my $sales_rank = $1;
$sales_rank =~ tr[,][]d;    # 4,070 becomes 4070
print "$sales_rank\n";
__END__

